import polars as pl
from retrofit.FeatureEngineering import FeatureEngineering


class FE(FeatureEngineering):
    def __init__(self) -> None:
        super().__init__()
